namespace Classes;

public class EmptyClass
{
    // Блок полей (переменных)
    // Блок конструктора
    // Блок методов и свойств
}