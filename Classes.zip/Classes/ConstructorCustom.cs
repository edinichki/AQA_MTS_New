namespace Classes;

public class ConstructorCustom
{
    public ConstructorCustom(int size)
    {
    }

    public ConstructorCustom(string text)
    {
    }
}