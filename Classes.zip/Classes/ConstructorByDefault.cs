namespace Classes;

public class ConstructorByDefault
{
    public ConstructorByDefault()
    {
    }
}