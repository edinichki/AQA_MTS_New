namespace Classes;

public class ConstructorFull
{
    public ConstructorFull()
    {
    }

    public ConstructorFull(int size)
    {
    }

    public ConstructorFull(string text)
    {
    }
}